# Kumar AI Assistant (Offline, Free)

**Kumar** is an Android AI assistant that runs 100% offline. It activates when you say **"Kumar"**, reads the screen via OCR, runs a local LLM (TinyLLaMA/Mistral) using `llama.cpp`, and can speak or type responses.

## Features
- Voice wake word **"Kumar"**
- Screen OCR (Google ML Kit)
- Offline LLM using GGUF model (place your model in `app/src/main/assets/models/`)
- Text-to-Speech voice reply
- Auto typing into focused input fields
- Voice reminders & basic app launching

## Requirements
- Android Studio Arctic Fox or newer
- Android device with **4 GB RAM**+
- Enable *Accessibility* and *Microphone* permissions

## Setup
1. Clone or unzip this project.
2. Download a small GGUF model (e.g., `tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf`) from [HuggingFace](https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF).
3. Place the model file in `app/src/main/assets/models/`.
4. Open the project in Android Studio, let it sync Gradle.
5. Connect your phone (USB Debugging on) or use an emulator.
6. Press **Run**.

## Usage
- Grant the Accessibility permission when prompted.
- Say **"Kumar"** followed by a command, e.g.  
  *“Kumar, what’s on screen?”*  
  *“Kumar, remind me tomorrow at 9 AM to study.”*  
  *“Kumar, open YouTube.”*

## Note
- The LLM bridge via `llama.cpp` JNI is provided as a placeholder; you may need to integrate Chaquopy or an NDK module to load GGUF. Check `MyAccessibilityService.kt -> runLLM()` for the integration point.

## License
MIT
